
<?php $__env->startSection('content'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/css/select2.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js"></script>



     <div class="page-header">
        <div class="row align-items-center">
          <div class="col"></div>
          <div class="col-auto">
          </div>
          
        </div>
        <!-- End Row -->
      </div>
        <h1 class="page--title">Tambah Data Droping </h1>
<br>
        <div class="container">
            <form action="<?php echo e(route('mylist.update',$kue->id)); ?>" method="POST">
              <?php echo e(method_field('PUT')); ?>

              <input type="text" name="id" id="" style="display: none" value="<?php echo e($kue->id); ?>">
                <?php echo csrf_field(); ?>

              <div class="w-md-50">
  <div class="mb-3">
    <label class="form-label" for="exampleFormControlInput1">Kue : </label>
    		<select class="theSelect form-select form-select-hover-light" name="id_kue">
      <?php $__currentLoopData = $cookie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option <?php echo e($cook->id == $kue->cookie->id ? 'selected' : ''); ?> value="<?php echo e($cook->id); ?>"><?php echo e($cook->nama); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
  </div>
              <!-- Form -->
              <div class="mb-3">
                <label for="formControlHoverLightFullName" class="form-label">Jumlah</label>

                <input type="number" required name="jumlah_droping" class="form-control form-control-hover-light" id="formControlHoverLightFullName" value="<?php echo e($kue->jumlah_droping); ?>" placeholder="Masukan Jumlah">
              </div>
              <!-- End Form -->
              <!-- End Form -->
            </div>
            <button type="submit" class="btn btn-outline-primary">Tambah Data</button>
</form>            
        </div>

        	<script>
		$(".theSelect").select2();
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manajemenkue\resources\views/mylist/edit.blade.php ENDPATH**/ ?>