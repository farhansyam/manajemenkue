
<?php $__env->startSection('content'); ?>
     <div class="page-header">
        <div class="row align-items-center">
          <div class="col"></div>
          <div class="col-auto">
            <a href="<?php echo e(route('droping.approval')); ?>">
            <button type="button" class="btn btn-outline-primary">Approval Droping </button>
            </a>
            <a href="<?php echo e(route('droping.create')); ?>">
            <button type="button" class="btn btn-outline-primary">New Droping </button>
            </a>
          </div>
          
        </div>
        <h1 class="page-header-title">Droping List</h1>
        <!-- End Row -->
      </div>
      <div class="div class="table-responsive"">
      <table class="table table-nowrap" id="example">
        <thead>
      <tr>
        <th>No</th>
        <th>Id User</th>
        <th>Status</th>
        <th>Tanggal Droping</th>
        <th>Option</th>
      </tr>
      
      </thead>

      <tbody>
        <?php
            $i = 1;
        ?>
        <?php $__currentLoopData = $dropings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $droping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($i++); ?></td>
        <td><?php echo e($droping->user->name); ?></td>
        <td ><?php if($droping->status == 2): ?>
              <span class="badge bg-soft-success text-success">Approved</span>
             <?php else: ?>
               <span class="badge bg-soft-warning text-warning">Pending</span>   
             <?php endif; ?>  
        </td>
        
        <td><?php echo e(date('d M Y',strtotime($droping->created_at))); ?></td>
        <td>
          <form method="POST" action="<?php echo e(route('droping.destroy',$droping->id_droping)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-danger btn-icon">
                      <i class="bi-trash"></i>
                    </button>
                    
                    <a href="<?php echo e(route('droping.show',$droping->id_droping)); ?>">
                      <button type="button" class="btn btn-warning btn-icon">
                        <i class="bi-eye"></i>
                      </button>
                    </a>
          </form>
        </td>
        
      </tr> 

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      </table>
      </div>
    <script src="<?php echo e(asset('vendor/jquery/dist/jquery.min.js')); ?>"></script>

      <script>
        $(document).ready(function () {
    $('#example').DataTable();
});
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manajemenkue\resources\views/droping/index.blade.php ENDPATH**/ ?>