
<?php $__env->startSection('content'); ?>
     <div class="page-header">
        <div class="row align-items-center">
          <div class="col"></div>
          <div class="col-auto">
            <a href="<?php echo e(url('mylist/create')); ?>">
            <button type="button" class="btn btn-outline-primary">Tambah Data</button>
            </a>
          </div>
          
        </div>
        <h1 class="page-header-title">Mylist Kue</h1>
        <!-- End Row -->
      </div>
      <div class="div class="table-responsive"">
      <table class="table table-nowrap" id="example">
        <thead>
        <?php if(auth()->user()->role == '99'): ?>
      <tr>
        <th>No</th>
        <th>Name</th>
        <th>Jenis</th>
        <th>Harga</th>
        <th>Jumlah Droping</th>
        <th>Stock</th>
        <th>Datang</th>
        <th>Opsi</th>
      </tr>
        <?php else: ?>
        <tr>
        <th>No</th>
        <th>Name</th>
        <th>Jenis</th>
        <th>Harga</th>
        <th>Jumlah Droping</th>
        <th>Stock</th>
        <th>Terjual</th>
        <th>Pesanan</th>
        <th>Return</th>
        <th>Setoran</th>
        <th>Piutang</th>
      </tr>
        <?php endif; ?>
      
      </thead>

      <tbody>
        <?php
            $i = 1;
        ?>
        <?php $__currentLoopData = $kues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(auth()->user()->role == '99'): ?>
      <tr>
        <td><?php echo e($i++); ?></td>
        <td><?php echo e($kue->cookie->nama); ?></td>
        <td><?php echo e($kue->cookie->jenis); ?></td>
        <td><?php echo e($kue->cookie->harga); ?></td>
        <td><?php echo e($kue->jumlah_droping); ?></td>
        <td><?php echo e($kue->stock); ?></td>
        <td><?php echo e(date('d M Y',strtotime($kue->created_at))); ?></td>
        <td>
          <form method="POST" action="<?php echo e(route('mylist.destroy',$kue->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-danger btn-icon">
                      <i class="bi-trash"></i>
                    </button>
                    <a href="<?php echo e(route('mylist.edit',$kue->id)); ?>">
                      <button type="button" class="btn btn-warning btn-icon">
                        <i class="bi-pencil"></i>
                      </button>
                    </a>
          </form>
        </td>
        
      </tr> 
        <?php else: ?>
         <tr>
        <td><?php echo e($i++); ?></td>
        <td><?php echo e($kue->cookie->nama); ?></td>
        <td><?php echo e($kue->cookie->jenis); ?></td>
        <td><?php echo e($kue->cookie->harga); ?></td>
        <td><?php echo e($kue->jumlah_droping); ?></td>
        <td><?php echo e($kue->stock); ?></td>
        <td><?php echo e($kue->terjual); ?></td>
        <td><?php echo e($kue->pesanan); ?></td>
        <td><?php echo e($kue->return); ?></td>
        <td><?php echo e($kue->setoran); ?></td>
        <td><?php echo e($kue->piutang); ?></td>
      </tr>
        <?php endif; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      </table>
      </div>
    <script src="<?php echo e(asset('vendor/jquery/dist/jquery.min.js')); ?>"></script>

      <script>
        $(document).ready(function () {
    $('#example').DataTable();
});
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manajemenkue\resources\views/mylist/index.blade.php ENDPATH**/ ?>