
<?php $__env->startSection('content'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/css/select2.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js"></script>



     <div class="page-header">
        <div class="row align-items-center">
          <div class="col"></div>
          <div class="col-auto">
          </div>
          
        </div>
        <!-- End Row -->
      </div>
        <h1 class="page--title">Tambah Data Droping </h1>
<br>
        <div class="container">
          <form action="<?php echo e(route('droping.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
              <div class="w-md-50">
  <div class="mb-3">
    
        <?php if($errors->any()): ?>
        <div class="alert alert-soft-danger" role="alert">
          Perhatikan Stok Kue
        </div>
    <?php endif; ?>
    <label class="form-label" for="exampleFormControlInput1">Akun Gudang : </label>
    		<select class="theSelect form-select form-select-hover-light" name="id_user">
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
    
  </div>
  <div class="mb-3">
    <?php
        // if($errors->first('id_kue')){
        //   echo "data kue sudah ada , "
        // };
    ?>
    <label class="form-label" for="exampleFormControlInput1">Stock Kue Gudang Ini : </label>
   
  </div>
              <!-- Form -->
              <div class="mb-3">
                <label for="formControlHoverLightFullName" class="form-label">Jumlah</label>

              </div>
              <!-- End Form -->
              <!-- End Form -->
            </div>
            <table class="table table-bordered">
              <thead>
                <tr>
                  <td>Kue</td>
                  <td>Jumlah</td>
                  <td><a href="#" onclick="adder()" class="btn btn-success addRow">+</a></td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <select class="theSelect form-select form-select-hover-light" name="id_kue[]">
                      <?php $__currentLoopData = $kues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kue->cookie->id); ?>"><?php echo e($kue->cookie->nama); ?> - Stock : <?php echo e($kue->stock); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </td>
                  <td>
                    <input type="number" required name="jumlah_droping[]" class="form-control form-control-hover-light" id="formControlHoverLightFullName" placeholder="Masukan Jumlah">
                  </td>
                  <td><a href='javascript:void(0)' class="btn btn-danger drow btn-disable" >-</a></td>

                </tr>
              </tbody>
            </table>
            <button type="submit" class="btn btn-outline-primary">Tambah Data</button>
</form>            
        </div>
        <script>
          function adder(){
             var tr =  `
                        <tr>
                  <td>
                    <select class="theSelect form-select form-select-hover-light" name="id_kue[]">
                      <?php $__currentLoopData = $kues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kue->cookie->id); ?>"><?php echo e($kue->cookie->nama); ?> - Stock : <?php echo e($kue->stock); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </td>
                  <td>
                    <input type="number" required name="jumlah_droping[]" class="form-control form-control-hover-light" id="formControlHoverLightFullName" placeholder="Masukan Jumlah">
                  </td>
                  <td><a href="javascript:void(0)" onclick="deleter()" class="btn btn-danger drow">-</a></td>

                </tr>`
             $('tbody').append(tr);
          }

          $('tbody').on('click','.drow',function(){
            $(this).parent().parent().remove()

          })
        </script>
        	<script>
		$(".theSelect").select2();
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manajemenkue\resources\views/droping/create.blade.php ENDPATH**/ ?>