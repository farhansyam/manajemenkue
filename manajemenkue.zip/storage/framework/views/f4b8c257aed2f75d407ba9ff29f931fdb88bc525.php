
<?php $__env->startSection('content'); ?>
     <div class="page-header">
        <div class="row align-items-center">
          <div class="col"></div>
          <div class="col-auto">
            
          </div>
          
        </div>
        <h1 class="page-header-title"> </h1><br>
          <table class="">
            <thead>
                <tr>
                  <th>Kode Droping</th>
                  <th> : <?php echo e($droping->id_droping); ?></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Tanggal Droping Kue</td>
                  <td> : <?php echo e($droping->created_at); ?></td>
                </tr>
                <tr>
                  <td>Total Kue</td>
                  <td> : <?php echo e($kues->sum('jumlah_droping')); ?></td>
                </tr>
                <tr>
                  <td>Penerima</td>
                  <td> : <?php echo e($droping->user->name); ?></td>
                </tr>
                <tr>
                  <td>Status</td>
                    <td ><?php if($droping->status == 2): ?>
                     : <span class="badge bg-soft-success text-success">Approved</span>
                  <?php else: ?>
                     : <span class="badge bg-soft-warning text-warning">Pending</span>   
                  <?php endif; ?>  
              </td>
                </tr>
              </tbody>
          </table>

        <!-- End Row -->
      </div>
      <div class="div class="table-responsive"">
      <table class="table table-nowrap" id="example">
        <thead>
        <?php if(auth()->user()->role == '99'): ?>
      <tr>
        <th>No</th>
        <th>Name</th>
        <th>Jenis</th>
        <th>Harga</th>
        <th>Jumlah Droping</th>
        
      </tr>
        <?php else: ?>
        <tr>
        <th>No</th>
        <th>Name</th>
        <th>Jenis</th>
        <th>Harga</th>
        <th>Jumlah Droping</th>
      </tr>
        <?php endif; ?>
      
      </thead>

      <tbody>
        <?php
            $i = 1;
        ?>
        <?php $__currentLoopData = $kues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(auth()->user()->role == '99'): ?>
      <tr>
        <td><?php echo e($i++); ?></td>
        <td><?php echo e($kue->cookie->nama); ?></td>
        <td><?php echo e($kue->cookie->jenis); ?></td>
        <td><?php echo e($kue->cookie->harga); ?></td>
        <td><?php echo e($kue->jumlah_droping); ?></td>
        <td><?php echo e($kue->created_at); ?></td>
        
        
      </tr> 
        <?php else: ?>
         <tr>
        <td><?php echo e($i++); ?></td>
        <td><?php echo e($kue->cookie->nama); ?></td>
        <td><?php echo e($kue->cookie->jenis); ?></td>
        <td><?php echo e($kue->cookie->harga); ?></td>
        <td><?php echo e($kue->jumlah_droping); ?></td>
      </tr>
        <?php endif; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      </table>
      </div>
    <script src="<?php echo e(asset('vendor/jquery/dist/jquery.min.js')); ?>"></script>

      <script>
        $(document).ready(function () {
    $('#example').DataTable();
});
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manajemenkue\resources\views/droping/show.blade.php ENDPATH**/ ?>