@extends('layouts.master')
@section('content')
    <!-- Page Header -->
      <div class="page-header">
        <div class="row align-items-center">
          <div class="col">
            <h1 class="page-header-title">Detail Akun Gudang {{$gudang->name}}</h1>
          </div>
          
          <!-- End Col -->

          <div class="col-auto">
          </div>
          
          <!-- End Col -->
        </div>
        <!-- End Row -->
      </div>
      <!-- End Page Header -->
      
      <!-- Stats -->
      <h3 class="title">Rekap Kue</h3>
      <br>
      <div class="row">
        <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
          <!-- Card -->
          <a class="card card-hover-shadow h-100" href="#">
            <div class="card-body">
              <h6 class="card-subtitle">Stok</h6>

              <div class="row align-items-center gx-2 mb-1">
                <div class="col-9">
                  <h2 class="card-title text-inherit">{{$stock}}</h2>
                </div>
                <!-- End Col -->

                <div class="col-3">
                  <!-- Chart -->
                <span class="icon" height="200">
                  <i class="bi-archive"></i>
                </span>
                  <!-- End Chart -->
                </div>
                <!-- End Col -->
              </div>
              <!-- End Row -->

              </span>
            </div>
          </a>
          <!-- End Card -->
        </div>
          <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
            <!-- Card -->
            <a class="card card-hover-shadow h-100" href="#">
              <div class="card-body">
                <h6 class="card-subtitle">Dropping</h6>
          
                <div class="row align-items-center gx-2 mb-1">
                  <div class="col-9">
                    <h2 class="card-title text-inherit">{{$jumlah_droping}}</h2>
                  </div>
                  <!-- End Col -->
          
                  <div class="col-3">
                    <!-- Chart -->
                    <span class="icon" height="200">
                      <i class="bi-calendar-week"></i>
                    </span>
                    <!-- End Chart -->
                  </div>
                  <!-- End Col -->
                </div>
                <!-- End Row -->
          
                </span>
              </div>
            </a>
            <!-- End Card -->
          </div>
            <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
              <!-- Card -->
              <a class="card card-hover-shadow h-100" href="#">
                <div class="card-body">
                  <h6 class="card-subtitle">Terjual</h6>
            
                  <div class="row align-items-center gx-2 mb-1">
                    <div class="col-9">
                      <h2 class="card-title text-inherit">540</h2>
                    </div>
                    <!-- End Col -->
            
                    <div class="col-3">
                      <!-- Chart -->
                      <span class="icon" height="200">
                        <i class="bi-cart-check-fill"></i>
                      </span>
                      <!-- End Chart -->
                    </div>
                    <!-- End Col -->
                  </div>
                  <!-- End Row -->
            
                  </span>
                </div>
              </a>
              <!-- End Card -->
            </div>
          <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
            <!-- Card -->
            <a class="card card-hover-shadow h-100" href="#">
              <div class="card-body">
                <h6 class="card-subtitle">Pesanan</h6>
          
                <div class="row align-items-center gx-2 mb-1">
                  <div class="col-9">
                    <h2 class="card-title text-inherit">540</h2>
                  </div>
                  <!-- End Col -->
          
                  <div class="col-3">
                    <!-- Chart -->
                    <span class="icon" height="200">
                      <i class="bi-list"></i>
                    </span>
                    <!-- End Chart -->
                  </div>
                  <!-- End Col -->
                </div>
                <!-- End Row -->
          
                </span>
              </div>
            </a>
            <!-- End Card -->
          </div>
          <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
          <!-- Card -->
          <a class="card card-hover-shadow h-100" href="#">
            <div class="card-body">
              <h6 class="card-subtitle">Return</h6>

              <div class="row align-items-center gx-2 mb-1">
                <div class="col-9">
                  <h2 class="card-title text-inherit">540</h2>
                </div>
                <!-- End Col -->

                <div class="col-3">
                  <!-- Chart -->
                <span class="icon" height="200">
                  <i class="bi-caret-left-square"></i>
                </span>
                  <!-- End Chart -->
                </div>
                <!-- End Col -->
              </div>
              <!-- End Row -->

              </span>
            </div>
          </a>
          <!-- End Card -->
        </div>
         
      </div>
            <h3 class="title">Rekap Tagihan Saya</h3>
            <br>
            <div class="row">
              <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
                <!-- Card -->
                <a class="card card-hover-shadow h-100" href="#">
                  <div class="card-body">
                    <h6 class="card-subtitle">Total Tagihan</h6>
            
                    <div class="row align-items-center gx-2 mb-1">
                      <div class="col-9">
                        <h2 class="card-title text-inherit">Rp.500000</h2>
                      </div>
                      <!-- End Col -->
            
                      <div class="col-3">
                        <!-- Chart -->
                        <span class="icon" height="200">
                          <i class="bi-cash-coin"></i>
                        </span>
                        <!-- End Chart -->
                      </div>
                      <!-- End Col -->
                    </div>
                    <!-- End Row -->
            
                    </span>
                  </div>
                </a>
                <!-- End Card -->
              </div>
              <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
                <!-- Card -->
                <a class="card card-hover-shadow h-100" href="#">
                  <div class="card-body">
                    <h6 class="card-subtitle">Setoran</h6>
            
                    <div class="row align-items-center gx-2 mb-1">
                      <div class="col-9">
                        <h2 class="card-title text-inherit">540</h2>
                      </div>
                      <!-- End Col -->
            
                      <div class="col-3">
                        <!-- Chart -->
                        <span class="icon" height="200">
                          <i class="bi-calendar-week"></i>
                        </span>
                        <!-- End Chart -->
                      </div>
                      <!-- End Col -->
                    </div>
                    <!-- End Row -->
            
                    </span>
                  </div>
                </a>
                <!-- End Card -->
              </div>
              <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
                <!-- Card -->
                <a class="card card-hover-shadow h-100" href="#">
                  <div class="card-body">
                    <h6 class="card-subtitle">Piutang</h6>
            
                    <div class="row align-items-center gx-2 mb-1">
                      <div class="col-9">
                        <h2 class="card-title text-inherit">540</h2>
                      </div>
                      <!-- End Col -->
            
                      <div class="col-3">
                        <!-- Chart -->
                        <span class="icon" height="200">
                          <i class="bi-cart-check-fill"></i>
                        </span>
                        <!-- End Chart -->
                      </div>
                      <!-- End Col -->
                    </div>
                    <!-- End Row -->
            
                    </span>
                  </div>
                </a>
                <!-- End Card -->
              </div>
              <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
                <!-- Card -->
                <a class="card card-hover-shadow h-100" href="#">
                  <div class="card-body">
                    <h6 class="card-subtitle">Sisa Tagihan</h6>
            
                    <div class="row align-items-center gx-2 mb-1">
                      <div class="col-9">
                        <h2 class="card-title text-inherit">540</h2>
                      </div>
                      <!-- End Col -->
            
                      <div class="col-3">
                        <!-- Chart -->
                        <span class="icon" height="200">
                          <i class="bi-list"></i>
                        </span>
                        <!-- End Chart -->
                      </div>
                      <!-- End Col -->
                    </div>
                    <!-- End Row -->
            
                    </span>
                  </div>
                </a>
                <!-- End Card -->
              </div>
            </div>
           <div class="page-header">
        <div class="row align-items-center">
          <div class="col"></div>
          <div class="col-auto">
            <a href="{{url('mylist/create')}}">
            <button type="button" class="btn btn-outline-primary">Tambah Data</button>
            </a>
          </div>
          
        </div>
        <h1 class="page-header-title">Mylist Kue</h1>
        <!-- End Row -->
      </div>
      <div class="div class="table-responsive"">
      <table class="table table-nowrap" id="example">
        <thead>
        @if(auth()->user()->role == '99')
      <tr>
        <th>No</th>
        <th>Name</th>
        <th>Jenis</th>
        <th>Harga</th>
        <th>Jumlah Droping</th>
        <th>Stock</th>
        <th>Datang</th>
        <th>Opsi</th>
      </tr>
        @else
        <tr>
        <th>No</th>
        <th>Name</th>
        <th>Jenis</th>
        <th>Harga</th>
        <th>Jumlah Droping</th>
        <th>Stock</th>
        <th>Terjual</th>
        <th>Pesanan</th>
        <th>Return</th>
        <th>Setoran</th>
        <th>Piutang</th>
      </tr>
        @endif
      
      </thead>

      <tbody>
        @php
            $i = 1;
        @endphp
        @foreach($kues as $kue)
        @if(auth()->user()->role == '99')
      <tr>
        <td>{{$i++}}</td>
        <td>{{$kue->cookie->nama}}</td>
        <td>{{$kue->cookie->jenis}}</td>
        <td>{{$kue->cookie->harga}}</td>
        <td>{{$kue->jumlah_droping}}</td>
        <td>{{$kue->stock}}</td>
        <td>{{date('d M Y',strtotime($kue->created_at))}}</td>
        <td>
          <form method="POST" action="{{route('mylist.destroy',$kue->id)}}">
            {{ csrf_field() }}
            {{ method_field('DELETE') }}
                    <button type="submit" class="btn btn-danger btn-icon">
                      <i class="bi-trash"></i>
                    </button>
                    <a href="{{route('mylist.edit',$kue->id)}}">
                      <button type="button" class="btn btn-warning btn-icon">
                        <i class="bi-pencil"></i>
                      </button>
                    </a>
          </form>
        </td>
        
      </tr> 
        @else
         <tr>
        <td>{{$i++}}</td>
        <td>{{$kue->cookie->nama}}</td>
        <td>{{$kue->cookie->jenis}}</td>
        <td>{{$kue->cookie->harga}}</td>
        <td>{{$kue->jumlah_droping}}</td>
        <td>{{$kue->stock}}</td>
        <td>{{$kue->terjual}}</td>
        <td>{{$kue->pesanan}}</td>
        <td>{{$kue->return}}</td>
        <td>{{$kue->setoran}}</td>
        <td>{{$kue->piutang}}</td>
      </tr>
        @endif

      @endforeach
      </tbody>
      </table>
      </div>
    <script src="{{asset('vendor/jquery/dist/jquery.min.js')}}"></script>

      <script>
        $(document).ready(function () {
    $('#example').DataTable();
});
      </script>
@endsection
