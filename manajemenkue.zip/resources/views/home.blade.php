@extends('layouts.master')
@section('content')
    <!-- Page Header -->
      <div class="page-header">
        <div class="row align-items-center">
          <div class="col">
            <h1 class="page-header-title">Dashboard</h1>
          </div>
          
          <!-- End Col -->

          <div class="col-auto">
          </div>
          
          <!-- End Col -->
        </div>
        <!-- End Row -->
      </div>
      <!-- End Page Header -->
      
      <!-- Stats -->
      <h3 class="title">Rekap Kue Saya</h3>
      <br>
      <div class="row">
        <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
          <!-- Card -->
          <a class="card card-hover-shadow h-100" href="#">
            <div class="card-body">
              <h6 class="card-subtitle">Stok</h6>

              <div class="row align-items-center gx-2 mb-1">
                <div class="col-9">
                  <h2 class="card-title text-inherit">{{$stock}}</h2>
                </div>
                <!-- End Col -->

                <div class="col-3">
                  <!-- Chart -->
                <span class="icon" height="200">
                  <i class="bi-archive"></i>
                </span>
                  <!-- End Chart -->
                </div>
                <!-- End Col -->
              </div>
              <!-- End Row -->

              </span>
            </div>
          </a>
          <!-- End Card -->
        </div>
          <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
            <!-- Card -->
            <a class="card card-hover-shadow h-100" href="#">
              <div class="card-body">
                <h6 class="card-subtitle">Dropping</h6>
          
                <div class="row align-items-center gx-2 mb-1">
                  <div class="col-9">
                    <h2 class="card-title text-inherit">{{$jumlah_droping}}</h2>
                  </div>
                  <!-- End Col -->
          
                  <div class="col-3">
                    <!-- Chart -->
                    <span class="icon" height="200">
                      <i class="bi-calendar-week"></i>
                    </span>
                    <!-- End Chart -->
                  </div>
                  <!-- End Col -->
                </div>
                <!-- End Row -->
          
                </span>
              </div>
            </a>
            <!-- End Card -->
          </div>
            <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
              <!-- Card -->
              <a class="card card-hover-shadow h-100" href="#">
                <div class="card-body">
                  <h6 class="card-subtitle">Terjual</h6>
            
                  <div class="row align-items-center gx-2 mb-1">
                    <div class="col-9">
                      <h2 class="card-title text-inherit">540</h2>
                    </div>
                    <!-- End Col -->
            
                    <div class="col-3">
                      <!-- Chart -->
                      <span class="icon" height="200">
                        <i class="bi-cart-check-fill"></i>
                      </span>
                      <!-- End Chart -->
                    </div>
                    <!-- End Col -->
                  </div>
                  <!-- End Row -->
            
                  </span>
                </div>
              </a>
              <!-- End Card -->
            </div>
          <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
            <!-- Card -->
            <a class="card card-hover-shadow h-100" href="#">
              <div class="card-body">
                <h6 class="card-subtitle">Pesanan</h6>
          
                <div class="row align-items-center gx-2 mb-1">
                  <div class="col-9">
                    <h2 class="card-title text-inherit">540</h2>
                  </div>
                  <!-- End Col -->
          
                  <div class="col-3">
                    <!-- Chart -->
                    <span class="icon" height="200">
                      <i class="bi-list"></i>
                    </span>
                    <!-- End Chart -->
                  </div>
                  <!-- End Col -->
                </div>
                <!-- End Row -->
          
                </span>
              </div>
            </a>
            <!-- End Card -->
          </div>
          <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
          <!-- Card -->
          <a class="card card-hover-shadow h-100" href="#">
            <div class="card-body">
              <h6 class="card-subtitle">Return</h6>

              <div class="row align-items-center gx-2 mb-1">
                <div class="col-9">
                  <h2 class="card-title text-inherit">540</h2>
                </div>
                <!-- End Col -->

                <div class="col-3">
                  <!-- Chart -->
                <span class="icon" height="200">
                  <i class="bi-caret-left-square"></i>
                </span>
                  <!-- End Chart -->
                </div>
                <!-- End Col -->
              </div>
              <!-- End Row -->

              </span>
            </div>
          </a>
          <!-- End Card -->
        </div>
         
      </div>
            <h3 class="title">Rekap Tagihan Saya</h3>
            <br>
            <div class="row">
              <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
                <!-- Card -->
                <a class="card card-hover-shadow h-100" href="#">
                  <div class="card-body">
                    <h6 class="card-subtitle">Total Tagihan</h6>
            
                    <div class="row align-items-center gx-2 mb-1">
                      <div class="col-9">
                        <h2 class="card-title text-inherit">Rp.500000</h2>
                      </div>
                      <!-- End Col -->
            
                      <div class="col-3">
                        <!-- Chart -->
                        <span class="icon" height="200">
                          <i class="bi-cash-coin"></i>
                        </span>
                        <!-- End Chart -->
                      </div>
                      <!-- End Col -->
                    </div>
                    <!-- End Row -->
            
                    </span>
                  </div>
                </a>
                <!-- End Card -->
              </div>
              <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
                <!-- Card -->
                <a class="card card-hover-shadow h-100" href="#">
                  <div class="card-body">
                    <h6 class="card-subtitle">Setoran</h6>
            
                    <div class="row align-items-center gx-2 mb-1">
                      <div class="col-9">
                        <h2 class="card-title text-inherit">540</h2>
                      </div>
                      <!-- End Col -->
            
                      <div class="col-3">
                        <!-- Chart -->
                        <span class="icon" height="200">
                          <i class="bi-calendar-week"></i>
                        </span>
                        <!-- End Chart -->
                      </div>
                      <!-- End Col -->
                    </div>
                    <!-- End Row -->
            
                    </span>
                  </div>
                </a>
                <!-- End Card -->
              </div>
              <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
                <!-- Card -->
                <a class="card card-hover-shadow h-100" href="#">
                  <div class="card-body">
                    <h6 class="card-subtitle">Piutang</h6>
            
                    <div class="row align-items-center gx-2 mb-1">
                      <div class="col-9">
                        <h2 class="card-title text-inherit">540</h2>
                      </div>
                      <!-- End Col -->
            
                      <div class="col-3">
                        <!-- Chart -->
                        <span class="icon" height="200">
                          <i class="bi-cart-check-fill"></i>
                        </span>
                        <!-- End Chart -->
                      </div>
                      <!-- End Col -->
                    </div>
                    <!-- End Row -->
            
                    </span>
                  </div>
                </a>
                <!-- End Card -->
              </div>
              <div class="col-sm-6 col-lg-3 mb-3 mb-lg-5">
                <!-- Card -->
                <a class="card card-hover-shadow h-100" href="#">
                  <div class="card-body">
                    <h6 class="card-subtitle">Sisa Tagihan</h6>
            
                    <div class="row align-items-center gx-2 mb-1">
                      <div class="col-9">
                        <h2 class="card-title text-inherit">540</h2>
                      </div>
                      <!-- End Col -->
            
                      <div class="col-3">
                        <!-- Chart -->
                        <span class="icon" height="200">
                          <i class="bi-list"></i>
                        </span>
                        <!-- End Chart -->
                      </div>
                      <!-- End Col -->
                    </div>
                    <!-- End Row -->
            
                    </span>
                  </div>
                </a>
                <!-- End Card -->
              </div>
            </div>
      
@endsection
