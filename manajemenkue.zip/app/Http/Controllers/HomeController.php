<?php

namespace App\Http\Controllers;
use App\Models\Kue;
use Auth;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        if(Auth::user()->role == 99){
            $jumlah_droping = Auth::user()->kue->sum('jumlah_droping');
            $stock = Auth::user()->kue->sum('stock');

        }
        elseif(Auth::user()->role == 98){
            $jumlah_droping = Auth::user()->kuedroping->sum('jumlah_droping');
            $stock = Auth::user()->kuedroping->sum('stock');

        }
        else{
            $jumlah_droping = Auth::user()->kuedroping->where('status',2)->sum('jumlah_droping');
            $stock = Auth::user()->kuedroping->where('status',2)->sum('stock');
        }

        // $stok = $jumlah_droping - $terjual;
        return view('home',compact('jumlah_droping','stock'));
    }
}
