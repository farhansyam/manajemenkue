<?php

namespace App\Http\Controllers;

use Auth;
use DB;
use Redirect;
use Illuminate\Http\Request;
use App\Models\Cookie;
use App\Models\Droping;
use App\Models\Kue;
use App\Models\Kuedroping;
use App\Models\User;
class DropingController extends Controller
{

   public function index()
    {
        if(Auth::user()->role == 99)
            $dropings = Droping::Where('id_droper',auth()->user()->id)->get();
        elseif(Auth::user()->role == 98)
            $dropings = Droping::Where('id_droper',auth()->user()->id)->get();
        else
            $dropings = Droping::Where('id_droper',auth()->user()->id)->get();
        return view('droping.index', compact('dropings'));
    }
   public function approval()
    {
        if(Auth::user()->role == 99){

            $dropings = Droping::Where('id_user',auth()->user()->id)->get();
        }
        elseif(Auth::user()->role == 98){

            $dropings = Droping::Where('id_user',auth()->user()->id)->get();
        }
        else
            $dropings = Droping::Where('id_user',auth()->user()->id)->get();

        return view('droping.approval', compact('dropings'));
    }

    public function approvin($id)
    {
        $droping = Droping::find($id);
        $kuedroping = Kuedroping::Where('id_droping',$droping->id_droping)->first();

        $kuedroping->update([
            'status' => 2
        ]);
        $droping->update([
            'status' => 2
        ]);

        return redirect('approvaldrop');
    }
    
   public function show($id)
    {
        $droping = Droping::find($id);
        $kues = Kuedroping::where('id_droping',$id)->get();
        return view('droping.show', compact('kues','droping'));
    }
    
    /**
     * create
     *
     * @return void
     */
    public function create()
    {
        // $kues = Cookie::where();

        $kues = Kuedroping::where('id_user',auth()->user()->id)->get();
        if(Auth::user()->role == 99){
            $users = User::Where('role',98)->get();
            $kues = Kue::where('id_user',auth()->user()->id)->get();

        }
        elseif(Auth::user()->role == 98){
            $users = User::Where('role',97)->where('kode_gudang_2','LIKE','%'.auth()->user()->kode_gudang_2.'%')->get();
            }
        elseif(Auth::user()->role ==  97){
            $users = User::Where('role',96)->where('kode_gudang_3','LIKE','%'.auth()->user()->kode_gudang_3.'%')->get();
        }

        return view('droping.create', compact('kues','users'));
    }
    
    /**
     * store
     *
     * @param  mixed $request
     * @return void
     */
    public function store(Request $request)
    {
        // multiple
        $uid = $request->id_user;
        $iddroping = date('Ymdhms');
        $jumlah_droping = $request->jumlah_droping;
        $id_kue = $request->id_kue;
        foreach($request->jumlah_droping as $jumlah)
        {
            $kue = Kue::where('id_kue',$request->id_kue AND 'id_user',auth()->user()->id)->first();
            if($kue < $jumlah_droping){

                return Redirect::back()->withErrors(['msg' => 'The Message']);
            }
        }
              $Droping = Droping::create([
                'id_droping'     => $iddroping,
                'id_user'     => $request->id_user,
                'id_droper'     => auth()->user()->id

                ]); 
        
        $id_kue = $request->id_kue;
        for($i = 0; $i < count($id_kue); $i++){
            
            //  $request->validate([
            //                 'jumlah_droping' => 'numeric|max:'.$kue[$i]->stock
            //             ]); 

                $datasave = [
                    'id_droping'     => $iddroping,
                    'jumlah_droping'     => $jumlah_droping[$i],
                    'stock'     => $jumlah_droping[$i],
                    'id_kue'     => $id_kue[$i],
                    'id_user'     => $uid
                ];
               $Kuedroping =  DB::table('kuedropings')->insert($datasave);

                $stockupdate = [
                    'stock' => $kue->stock - $request->jumlah_droping[$i]
                ];
        $kue->update($stockupdate);
          

        }
        // single
        // $kue = Kue::where('id_kue',$request->id_kue AND 'id_user',auth()->user()->id)->first();
        // $iddroping = date('Ymdhms');

  

        // $kue->update([
        //     'stock' => $kue->stock - $request->jumlah_droping
        // ]);
          
        //   $Droping = Droping::create([
        //     'id_droping'     => $iddroping,
        //     'id_user'     => $request->id_user,
        //     'id_droper'     => auth()->user()->id

        // ]);  
     
        // $Kuedroping = Kuedroping::create([
        //     'id_droping'     => $iddroping,
        //     'jumlah_droping'     => $request->jumlah_droping,
        //     'stock'     => $request->jumlah_droping,
        //     'id_kue'     => $request->id_kue,
        //     'id_user'     => $request->id_user
        // ]);
        

      
        if($Droping AND $Kuedroping){
            //redirect dengan pesan sukses
            return redirect()->route('droping.index')->with(['success' => 'Data Berhasil Disimpan!']);
        }else{
            //redirect dengan pesan error
            return redirect()->route('droping.index')->with(['error' => 'Data Gagal Disimpan!']);
        }
    }
    
    /**
     * edit
     *
     * @param  mixed $Droping
     * @return void
     */
    public function edit($id)
    {   
        $cookie = Cookie::all();
        $Droping = Droping::find($id);
        // dd($Droping->cookie->id);
        return view('droping.edit', compact('Droping','cookie'));
    }
    
    /**
     * update
     *
     * @param  mixed $request
     * @param  mixed $Droping
     * @return void
     */
    public function update(Request $request)
    {
        // $this->validate($request, [
        //     'content'   => 'required'
        // ]);

        //get data Droping by ID
        $Droping = Droping::findOrFail($request->id);

        // if($request->file('image') == "") {

            $Droping->update([
                'id_Droping'     => $request->id_Droping,
                'jumlah_droping'   => $request->jumlah_droping
            ]);

        // } else {

        //     //hapus old image
        //     Storage::disk('local')->delete('public/dropings/'.$Droping->image);

        //     //upload new image
        //     $image = $request->file('image');
        //     $image->storeAs('public/dropings', $image->hashName());

        //     $Droping->update([
        //         'image'     => $image->hashName(),
        //         'title'     => $request->title,
        //         'content'   => $request->content
        //     ]);
            
        // }

        if($Droping){
            //redirect dengan pesan sukses
            return redirect()->route('droping.index')->with(['success' => 'Data Berhasil Diupdate!']);
        }else{
            //redirect dengan pesan error
            return redirect()->route('droping.index')->with(['error' => 'Data Gagal Diupdate!']);
        }
    }
    
    /**
     * destroy
     *
     * @param  mixed $id
     * @return void
     */
    public function destroy($id)
    {
        $Droping = Droping::findOrFail($id);
        $Droping->delete();

        if($Droping){
            //redirect dengan pesan sukses
            return redirect()->route('droping.index')->with(['success' => 'Data Berhasil Dihapus!']);
        }else{
            //redirect dengan pesan error
            return redirect()->route('droping.index')->with(['error' => 'Data Gagal Dihapus!']);
        }
    }

}
