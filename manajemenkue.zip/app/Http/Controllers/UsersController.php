<?php

namespace App\Http\Controllers;

use Auth;
use Hash;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Kue;
use App\Models\Kuedroping;
class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   public function index()
    {
        if(Auth::user()->role == 99)
        {
                $users = User::Where('role',98)->get();
        }
        elseif(Auth::user()->role == 98)
        {
            $users = User::Where('role',97)->get();
        }
        elseif(Auth::user()->role == 97)
        {
            $users = User::Where('role',96)->get();
        }
        return view('users.index', compact('users'));
    }
    
    /**
     * create
     *
     * @return void
     */
    public function create()
    {
        return view('users.create');
    }
    
    /**
     * store
     *
     * @param  mixed $request
     * @return void
     */
    public function store(Request $request)
    {
        // $this->validate($request, [
        //     'id_users'   => 'unique:users'
        // ]);

        //upload image
        // $image = $request->file('image');
        // $image->storeAs('public/users', $image->hashName());
        if(Auth::user()->role == 99)
             $users = User::create([
            'name'     => $request->name,
            'email'     => $request->email,
            'password' => Hash::make($request->password),
            'no_tlpn' => $request->no_telepon,
            'kode_gudang_2' => $request->kode_gudang,  
            'role' => 98,  
        ]);

        elseif(Auth::user()->role == 98)
             $users = User::create([
            'name'     => $request->name,
            'email'     => $request->email,
            'password' => Hash::make($request->password),
            'no_tlpn' => $request->no_telepon,
            'kode_gudang_2' => Auth::user()->kode_gudang_2,  
            'kode_gudang_3' => $request->kode_gudang,  
            'role' => 97,  
        ]);
        else
            $users = User::create([
                'name'     => $request->name,
                'email'     => $request->email,
                'password' => Hash::make($request->password),
                'no_tlpn' => $request->no_telepon,
                'kode_gudang_2' => Auth::user()->kode_gudang_2,  
                'kode_gudang_3' => Auth::user()->kode_gudang_3+3,  
                'kode_sales' => $request->kode_gudang,  
                'role' => 96,  
            ]);

        if($users){
            //redirect dengan pesan sukses
            return redirect()->route('users.index')->with(['success' => 'Data Berhasil Disimpan!']);
        }else{
            //redirect dengan pesan error
            return redirect()->route('users.index')->with(['error' => 'Data Gagal Disimpan!']);
        }
    }
    
    /**
     * edit
     *
     * @param  mixed $users
     * @return void
     */
    public function edit($id)
    {   
        $user = User::find($id);
        // dd($users->cookie->id);
        return view('users.edit', compact('user'));
    }
    
    /**
     * update
     *
     * @param  mixed $request
     * @param  mixed $users
     * @return void
     */
    public function update(Request $request)
    {
        // $this->validate($request, [
        //     'content'   => 'required'
        // ]);

        //get data users by ID
        $users = User::findOrFail($request->id);

        // if($request->file('image') == "") {

            $users->update([
                'name'     => $request->name,
                'email'   => $request->email,
                'password' => Hash::make($request->password),

            ]);

            if(Auth::user()->role == 99)
                $users->update([
                'name'     => $request->name,
                'email'     => $request->email,
                'password' => Hash::make($request->password),
                'no_tlpn' => $request->no_telepon,
                'kode_gudang_2' => $request->kode_gudang,  
                'role' => 98,  
                ]);

            elseif(Auth::user()->role == 98)
                 $users->update([
                'name'     => $request->name,
                'email'     => $request->email,
                'password' => Hash::make($request->password),
                'no_tlpn' => $request->no_telepon,
                'kode_gudang_3' => $request->kode_gudang,  
                'role' => 97,  
            ]);

            else
                 $users->update([
                    'name'     => $request->name,
                    'email'     => $request->email,
                    'password' => Hash::make($request->password),
                    'no_tlpn' => $request->no_telepon,
                    'kode_sales' => $request->kode_gudang,  
                    'role' => 96,  
                ]);



        // } else {

        //     //hapus old image
        //     Storage::disk('local')->delete('public/users/'.$users->image);

        //     //upload new image
        //     $image = $request->file('image');
        //     $image->storeAs('public/users', $image->hashName());

        //     $users->update([
        //         'image'     => $image->hashName(),
        //         'title'     => $request->title,
        //         'content'   => $request->content
        //     ]);
            
        // }

        if($users){
            //redirect dengan pesan sukses
            return redirect()->route('users.index')->with(['success' => 'Data Berhasil Diupdate!']);
        }else{
            //redirect dengan pesan error
            return redirect()->route('users.index')->with(['error' => 'Data Gagal Diupdate!']);
        }
    }
    
    /**
     * destroy
     *
     * @param  mixed $id
     * @return void
     */
    public function destroy($id)
    {
        $users = User::findOrFail($id);
        $users->delete();

        if($users){
            //redirect dengan pesan sukses
            return redirect()->route('users.index')->with(['success' => 'Data Berhasil Dihapus!']);
        }else{
            //redirect dengan pesan error
            return redirect()->route('users.index')->with(['error' => 'Data Gagal Dihapus!']);
        }
    }

    public function detail($id)
    {
        $gudang = User::find($id);

         if(Auth::user()->role == 99)
        {
            $kues = Kuedroping::Where('id_user',$gudang->id)->where('status',2)->get();
        }
        elseif(Auth::user()->role == 98)
        {
            $kues = Kuedroping::Where('id_user',auth()->user()->id)->where('status',2)->get();
        }
        else
        {
            $kues = Kuedroping::Where('id_user',auth()->user()->id)->where('status',2)->get();
        }
        $gudang = User::find($id);
            $jumlah_droping = $gudang->kuedroping->where('status',2)->sum('jumlah_droping');
            $stock = $gudang->kuedroping->where('status',2)->sum('stock');

        // $stok = $jumlah_droping - $terjual;
        return view('users.detail',compact('jumlah_droping','stock','gudang','kues'));
    }
    // public function detailgudang($id)
    // {
    //     $gudang = User::find($id);
    //     if(Auth::user()->role == 99)
    //     {
    //             $users = User::Where('role',96)->where('kode_gudang_2',$gudang->kode_gudang_2)->get();
    //     }
    //     elseif(Auth::user()->role == 98)
    //     {
    //         $users = User::Where('role',97)->get();
    //     }
    //     elseif(Auth::user()->role == 97)
    //     {
    //         $users = User::Where('role',96)->get();
    //     }
    //         $jumlah_droping = $gudang->kuedroping->where('status',2)->sum('jumlah_droping');
    //         $stock = $gudang->kuedroping->where('status',2)->sum('stock');

    //     // $stok = $jumlah_droping - $terjual;
    //     return view('users.detail',compact('jumlah_droping','stock','gudang','users'));
    // }

}
